package tech.inno.tretyakov;

import org.junit.Test;
import java.util.NoSuchElementException;

public class AccountTests {

    // Тест для проверки невозможности создания счета с именем = null
    @Test
    public void createAccountWithNullName(){
        try {
            Account testPerson = new Account(null);
        } catch (IllegalArgumentException e) {return;}
        throw new RuntimeException("Тест создания счета с именем = null провален!");
    }

    // Тест для проверки невозможности создания счета с пустым именем
    @Test
    public void createAccountWithEmptyName(){
        try {
            Account testPerson = new Account("");
        } catch (IllegalArgumentException e) {return;}
        throw new RuntimeException("Тест создания счета с пустым именем провален!");
    }

    // Тест для проверки невозможности установки количества валюты, которая не входит в список разрешенных валют
    @Test
    public void setCurrencyWichNotAllowed(){
        Account testPerson = new Account("TestPerson");
        try {
            testPerson.putAmountOfCurrency(Currency.XAU, 1000);
        } catch (IllegalArgumentException e) {return;}
        throw new RuntimeException("Тест на недопустимую валюту провален!");
    }

    // Тест для проверки установки количества валюты, которая входит в список разрешенных валют
    @Test
    public void setCurrencyWichAllowed(){
        Account testPerson = new Account("TestPerson");
        try {
            testPerson.putAmountOfCurrency(Currency.RUB, 1000);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Тест на допустимую валюту провален!");
        }
    }

    // Тест для проверки установки отрицательного количества валюты
    @Test
    public void setNegativeCurrency(){
        Account testPerson = new Account("TestPerson");
        try {
            testPerson.putAmountOfCurrency(Currency.RUB, -1000);
        } catch (IllegalArgumentException e) {return;}
            throw new RuntimeException("Тест на отрицательное количество валюты провален!");
    }

    // Тест для проверки установки положительного количества валюты
    @Test
    public void setPositiveCurrency(){
        Account testPerson = new Account("TestPerson");
        try {
            testPerson.putAmountOfCurrency(Currency.RUB, 1000);
            testPerson.putAmountOfCurrency(Currency.RUB, 0);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Тест на положительное количество валюты провален!");
        }
    }

    // Тест для проверки возникновения исключения при попытке отмены при пустой истории отмены
    @Test
    public void checkUndoNothing(){
        Account testPerson = new Account("TestPerson");
        try {
            testPerson.undo();
        }
            catch (NothingToUndo e) {return;}
            catch (NoSuchElementException e){
                throw new RuntimeException("Тест на отмену операции при пустой истории провален!");
            }
    }

    // Тест для проверки отмены изменения количества валюты
    @Test
    public void checkUndoChangeAmount(){
        Account testPerson = new Account("TestPerson");
            testPerson.putAmountOfCurrency(Currency.RUB, 1000);
            testPerson.putAmountOfCurrency(Currency.RUB, 10);
            testPerson.undo();
            Integer currentAmount = testPerson.getCurrencyAmount(Currency.RUB);
            assert currentAmount == 1000: "Тест на отмену установки нового значения кол-ва провален = " + currentAmount;
        }

    // Тест для проверки отмены первоначальной устновки количества валюты
    @Test
    public void checkUndoInitAmount(){
        Account testPerson = new Account("TestPerson");
        testPerson.putAmountOfCurrency(Currency.RUB, 1000);
        testPerson.undo();
        assert !testPerson.getFinancialAssets().containsKey(Currency.RUB) : "Тест на отмену установки первоначального значения кол-ва провален";
    }

    // Тест для проверки возможности сохранения и восстановления состояния Account
    @Test
    public void checkSaveAndLoad(){
        Account testPerson = new Account("TestPerson");
        testPerson.putAmountOfCurrency(Currency.RUB, 1000);
        testPerson.Save();
        assert testPerson.getHistoryOfState().size() > 0 : "Тест на возможность сохранить состояние провален!";
        testPerson.setOwnerName("NewPerson");
        testPerson.putAmountOfCurrency(Currency.RUB, 500);
        Loadable snapshot = testPerson.getHistoryOfState().getFirst();
        snapshot.load();
        assert testPerson.getOwnerName().equals("TestPerson") && testPerson.getCurrencyAmount(Currency.RUB) == 1000 : "Тест на возможность восстановить состояние провален!";
    }

    // Тест для проверки возможности отмены действия
    @Test
    public void checkIsUndoPossible(){
        Account testPerson = new Account("TestPerson");
        testPerson.putAmountOfCurrency(Currency.RUB, 1000);
        assert testPerson.isUndoPossible() : "Тест на проверку возможности отмены действия провален (отмена возможна)!";
        testPerson.undo();
        assert !testPerson.isUndoPossible() : "Тест на проверку возможности отмены действия провален (отмена невозможна)!";
    }

}

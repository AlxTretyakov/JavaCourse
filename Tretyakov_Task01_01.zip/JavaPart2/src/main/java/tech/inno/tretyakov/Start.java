package tech.inno.tretyakov;

public class Start {
    public static void main(String[] args) {
        Loadable snapshot;

        System.out.println("--------");
        System.out.println("Создадим новый объект Account, установим значения для RUB и USD, сохраним начальное состояние");

        Account account = new Account("Account 1");
        account.putAmountOfCurrency(Currency.RUB, 100);
        account.putAmountOfCurrency(Currency.USD, 200);

        System.out.println("Начальное состояние:");
        System.out.println(account);
        account.Save();
        System.out.println("Количество сохраненных состояний: " + account.getHistoryOfState().size());
        System.out.println("--------");

        System.out.println("Изменим имя, количество валюты RUB и USD, добавим валюту EUR, сохраним состояние:");
        account.setOwnerName("Account 2");
        account.putAmountOfCurrency(Currency.RUB, 555);
        account.putAmountOfCurrency(Currency.USD, 666);
        account.putAmountOfCurrency(Currency.EUR, 777);
        account.Save();
        System.out.println(account);
        System.out.println("Количество сохраненных состояний: " + account.getHistoryOfState().size());
        System.out.println("--------");

        System.out.println("Отменим 2 последних действия, сохраним состояние");
        account.undo();
        account.undo();
        System.out.println(account);
        account.Save();
        System.out.println("Количество сохраненных состояний: " + account.getHistoryOfState().size());
        System.out.println("--------");

        System.out.println("Проверим возможность отмены действия: " + account.isUndoPossible());
        System.out.println("--------");

        System.out.println("Восстановим самый первый сохраненный вариант состояния:");
        snapshot = account.getHistoryOfState().getFirst();
        snapshot.load();
        System.out.println(account);
        System.out.println("--------");

        System.out.println("Восстановим самый последний сохраненный вариант состояния:");
        snapshot = account.getHistoryOfState().getLast();
        snapshot.load();
        System.out.println(account);

        System.out.println("--------");
        System.out.println("Отменим последние изменение у только что восстановленного объекта (исключение NothingToUndo)");
        System.out.println("Проверим возможность отмены действия: " + account.isUndoPossible());
        account.undo();
    }
}

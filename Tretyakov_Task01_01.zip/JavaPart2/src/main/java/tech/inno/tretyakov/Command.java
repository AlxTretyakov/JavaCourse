package tech.inno.tretyakov;

public interface Command {
    void perform();
}

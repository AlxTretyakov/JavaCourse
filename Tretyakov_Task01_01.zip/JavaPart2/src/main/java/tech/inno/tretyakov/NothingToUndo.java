package tech.inno.tretyakov;

public class NothingToUndo extends RuntimeException{
}

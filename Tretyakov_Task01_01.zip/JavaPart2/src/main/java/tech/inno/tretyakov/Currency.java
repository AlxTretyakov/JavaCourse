package tech.inno.tretyakov;

public enum Currency {
    RUB("Российский рубль", "643"),
    USD("Доллар США", "840"),
    EUR("Евро", "978"),
    AED("Дирхам (ОАЭ)", "784"),
    XAU("Золото (тройская унция)", "959"),
    XAG("Серебро (тройская унция)", "961");
    private final String name;
    private final String iso;

    Currency(String name, String iso){
        this.name = name;
        this.iso = iso;
    }

    @Override
    public String toString() {
        return "Currency{" +
                "name='" + name + '\'' +
                ", iso='" + iso + '\'' +
                '}';
    }
}

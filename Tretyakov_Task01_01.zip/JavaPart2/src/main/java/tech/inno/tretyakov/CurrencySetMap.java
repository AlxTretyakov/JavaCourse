package tech.inno.tretyakov;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public class CurrencySetMap<E extends Enum<E>, V> extends HashMap<E, V> implements Map<E, V> {
    private final EnumSet<E> allowedCurrencySet;

    public CurrencySetMap(EnumSet<E> allowedCurrencySet) {
        this.allowedCurrencySet = allowedCurrencySet;
    }

    @Override
    public V put(E key, V value) {
        if (!(value instanceof Integer)) {
            throw new IllegalArgumentException("Количество валюты должно быть целым числом и не null!");
        }
        else {
            if ((Integer) value < 0){
                throw new IllegalArgumentException("Количество валюты не может быть отрицательным!");
            }
        }

        if (!allowedCurrencySet.contains(key))
            throw new IllegalArgumentException("Такой валюты не предусмотрено для данного счета!");
        return super.put(key, value);
    }

}
package tech.inno.tretyakov;

public interface Loadable {
    void load();
}

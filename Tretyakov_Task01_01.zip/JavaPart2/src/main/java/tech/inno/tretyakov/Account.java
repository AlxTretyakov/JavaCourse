package tech.inno.tretyakov;

import java.util.*;

public class Account {
    private String ownerName;
    private HashMap<Currency, Integer> financialAssets = new CurrencySetMap<>(EnumSet.of(Currency.RUB,Currency.USD,Currency.EUR,Currency.AED));
    private final Deque<Command> commands = new ArrayDeque<>();
    private final LinkedList<Snapshot> historyOfState = new LinkedList<>();

    public Loadable Save(){
        return new Snapshot();
    }

    private class Snapshot implements Loadable{
        private final String ownerName;
        private final HashMap<Currency, Integer> financialAssets;

        // Для задачи решил достаточным сохранять только 2 поля, можно сохранять и историю команд
        public Snapshot(){
            this.ownerName = Account.this.ownerName;
            this.financialAssets = new HashMap<>(Account.this.financialAssets);
            Account.this.historyOfState.add(this);
        }

        @Override
        public void load(){
            Account.this.ownerName = this.ownerName;
            Account.this.financialAssets = new HashMap<>(this.financialAssets);
            // В этом варианте при восстановлении состояния решил очищать историю команд:
            Account.this.commands.clear();
        }

        @Override
        public String toString() {
            return "Snapshot{ownerName='" + ownerName + '\'' +
                    ", financialAssets=" + financialAssets +
                    '}';
        }
    }

    public Account(String ownerName) {
        setOwnerName(ownerName);
    }

    public LinkedList<Snapshot> getHistoryOfState() {
        return new LinkedList<>(this.historyOfState);
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        if (ownerName == null || ownerName.isEmpty()) {
            throw new IllegalArgumentException("Имя не может быть пустым или null!");
        }
        String oldOwnerName = this.ownerName;
        if (oldOwnerName != null) {
            this.commands.push(()->{this.ownerName = oldOwnerName;});
        }
        this.ownerName = ownerName;
    }

    public HashMap<Currency, Integer> getFinancialAssets() {
        return new HashMap<>(financialAssets);
    }

    public void putAmountOfCurrency(Currency currency, int amount){
        Integer oldAmount = getCurrencyAmount(currency);
        if (financialAssets.containsKey(currency)) {
            this.commands.push(()->{financialAssets.put(currency, oldAmount);});
        } else {
            this.commands.push(()->{removeAmountOfCurrency(currency);});
        }
        financialAssets.put(currency, amount);
    }

    public void removeAmountOfCurrency(Currency currency){
        financialAssets.remove(currency);
    }

    public Integer getCurrencyAmount(Currency currency){
        if (financialAssets.containsKey(currency)) {
            return this.financialAssets.get(currency);
        }
        else {
            return null;
        }
    }

    public boolean isUndoPossible(){
        return !this.commands.isEmpty();
    }

    public Account undo() throws NothingToUndo{
        if (!isUndoPossible()) throw new NothingToUndo();
        commands.pop().perform();
        return this;
    }

    @Override
    public String toString() {
        return "Account{" +
                "ownerName='" + ownerName + "', FinancialAssets = " + this.getFinancialAssets().toString()  +
                '}';
    }

}
